pub mod build;
pub mod build_targets;
pub mod cli;
pub mod install;
pub mod pkg_config_gen;
pub mod static_libs;
pub mod target;
